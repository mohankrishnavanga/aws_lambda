import os
import sys

print "Hello world"
